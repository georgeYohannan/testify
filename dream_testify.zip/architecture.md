# Testify - Bible Quiz App Architecture

## Technical Overview
Testify is a faith-based quiz application featuring Bible questions, user authentication, and an encouraging elephant mascot. The app integrates with Supabase for backend services and data storage.

## Core Features (MVP)
1. **User Authentication** - Email/password login and signup
2. **Quiz System** - Multiple-choice questions with 3 difficulty levels
3. **Bible Book Selection** - Choose from available Bible books
4. **Verse of the Day** - Daily inspirational verses
5. **Quiz History** - Track performance and progress
6. **Elephant Mascot** - Encouraging reactions during quizzes

## App Structure (10 files total)

### 1. Models & Data (`lib/models/`)
- **user.dart** - User data model for authentication
- **quiz.dart** - Quiz question and result models
- **verse.dart** - Daily verse model

### 2. Services (`lib/services/`)
- **supabase_service.dart** - Authentication and database operations
- **quiz_service.dart** - Quiz logic and question management

### 3. Widgets (`lib/widgets/`)
- **elephant_mascot.dart** - Animated mascot widget
- **verse_card.dart** - Daily verse display component

### 4. Screens (`lib/screens/`)
- **splash_screen.dart** - Welcome screen with mascot and daily verse
- **auth_screen.dart** - Login/signup interface
- **dashboard_screen.dart** - Main hub with quiz history and new quiz button
- **quiz_setup_screen.dart** - Book selection and difficulty choice
- **quiz_screen.dart** - Question interface with mascot feedback
- **results_screen.dart** - Score summary and encouragement

### 5. Core Files
- **main.dart** - App entry point and routing
- **theme.dart** - App theming with sky blue/orange palette

## Data Flow
1. User authentication through Supabase
2. Quiz questions fetched based on book/difficulty selection
3. Progress tracking stored in quiz_history table
4. Random verse selection for daily inspiration
5. Local state management for quiz sessions

## Key Technical Decisions
- **Supabase Integration** - Backend as a service for auth and data
- **Material 3 Design** - Modern UI with rounded components
- **Stateful Widgets** - For interactive quiz and animation states
- **Future/Async** - For database operations and API calls
- **Local Sample Data** - Pre-populated questions for immediate testing

## Implementation Priority
1. Setup Supabase integration and data models
2. Implement authentication flow
3. Create quiz system with sample data
4. Design mascot animations and feedback
5. Build complete user journey
6. Add polish and testing

## Success Metrics
- Smooth authentication flow
- Engaging quiz experience with mascot feedback
- Clear progress tracking
- Inspirational daily verse feature
- Kid-friendly, accessible design